package com.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@SpringBootConfiguration
@ContextConfiguration
class ApplicationTests {

	@Test
	void contextLoads() {
	}

}
